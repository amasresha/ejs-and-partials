var express =require("express");
var app =express();

app.use(express.static("public"));
app.set("view engine", "ejs")
app.get("/",(req,res)=>{
  res.render("home");
})

app.get("/post",(req,res)=>{
  var posts = [
    {title:"Life after death", author:"Abe" },
    {title:"Happiness is what you need", author:"Tina"},
    {title:"The future is on AI", author:"Ethan"}
  ];
  res.render("book", {posts:posts});
})
app.get ("/:thing", (req,res)=>{
  var thing = req.params.thing;
  res.render ("love.ejs",{thingvar:thing})  ;
});
app.listen(2576, ()=>{
  console.log("Connecting to your awesome server at port 2576!");
})
